import 'package:hedieaty/models/Friend.dart';
import 'package:hedieaty/models/User.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';


import '../main.dart';


 const String fileName = "app_database.db";

class DatabaseHelper {

 static final DatabaseHelper _instance = DatabaseHelper._internal();

 factory DatabaseHelper() => _instance;
 static Database? _database;

 DatabaseHelper._internal();

 // Singleton instance for database
 Future<Database> get database async {
  if (_database != null) {
   return _database!;
  }
  _database = await _initializeDB(fileName);
  return _database!;
 }

 Future<Database> _initializeDB(String fileName) async {
  final dbPath = await getDatabasesPath();
  final path = join(dbPath, fileName);

  return await openDatabase(
   path,
   version: 1, // Database version
   onCreate: _createDB,
  );
 }

 Future<void> _createDB(Database db, int version) async {
  await db.execute(
      '''
      CREATE TABLE Users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        preferences TEXT
      );
      '''

  );


  await db.execute(
      '''
      CREATE TABLE Friends(
      userId INTEGER  ,
      friendId INTEGER KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      profilePic TEXT NOT NULL,
      upcomingEvents INTEGER NOT NULL,
      PRIMARY KEY (userId, friendId),
        FOREIGN KEY (userId) REFERENCES Users (id),
        FOREIGN KEY (friendId) REFERENCES Users (id)
 
      );
      
      
      '''
  );

  await db.execute('''
      CREATE TABLE Events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        date TEXT NOT NULL,
        location TEXT,
        description TEXT,
        userId INTEGER,
        FOREIGN KEY (userId) REFERENCES Users (id)
      );
    ''');

  await db.execute('''
      CREATE TABLE Gifts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        category TEXT,
        price REAL,
        status TEXT,
        eventId INTEGER,
        FOREIGN KEY (eventId) REFERENCES Events (id)
      );
    ''');
 }


 static Future<List<Friend>> getFriends() async {
  final db = await DatabaseHelper().database;
  final List<Map<String, dynamic>> maps = await db.query('Friends');
  return List.generate(maps.length, (i) => Friend.fromMap(maps[i]));
 }

 Future<int> insertFriend(Friend friend) async {
  final db = await database; // Get the database instance
  return await db.insert(
   'Friends', // The name of the Friends table
   friend.toMap(), // Convert the Friend object to a map for insertion
   conflictAlgorithm: ConflictAlgorithm.replace, // Handle conflicts by replacing
  );
 }


 Future<int> updateFriend(Friend friend) async{

  final db = await DatabaseHelper().database;
  return await db.update('Friends', friend.toMap(), where: 'friendId = ?', whereArgs: [friend.friendId]);


 }

 Future<int> deleteFriend(Friend friend) async {
  final db = await DatabaseHelper().database;
  return await db.delete('Friends', where: 'friendId = ?', whereArgs: [friend.friendId]);
 }




}
