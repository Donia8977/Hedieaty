import 'DatabaseHelper.dart';

class Event {

  final int? id;
  final String name;
  final String date;
  final String? location;
  final String? description;
  final int userId;

  Event({this.id, required this.name, required this.date, this.location, this.description, required this.userId});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'date': date,
      'location': location,
      'description': description,
      'userId': userId,
    };
  }

  factory Event.fromMap(Map<String, dynamic> map) {
    return Event(
      id: map['id'],
      name: map['name'],
      date: map['date'],
      location: map['location'],
      description: map['description'],
      userId: map['userId'],
    );
  }

  Future<int> insertUsers(Event event) async{

    final db = await DatabaseHelper().database;
    return await db.insert('Events', event.toMap());

  }

  Future<Event?> getEventById(int id) async {
    final db = await DatabaseHelper().database;
    final List<Map<String, dynamic>> maps = await db.query(
      'Events',
      where: 'id = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return Event.fromMap(maps.first);
    } else {
      return null;
    }
  }


  Future<int> updateEvents(Event event) async{

    final db = await DatabaseHelper().database;
    return await db.update('Events', event.toMap(), where: 'id = ?', whereArgs: [event.id]);


  }

  Future<int> deleteEvents(Event event) async {
    final db = await DatabaseHelper().database;
    return await db.delete('Events', where: 'id = ?', whereArgs: [id]);
  }





}